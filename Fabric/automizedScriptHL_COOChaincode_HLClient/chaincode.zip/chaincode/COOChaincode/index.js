'use strict';

const COOChaincode = require('./lib/COOChaincode');

module.exports.COOChaincode = COOChaincode;
module.exports.contracts = [ COOChaincode ];
